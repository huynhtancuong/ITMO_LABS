public interface Describeable {
    String getDescription();

}
